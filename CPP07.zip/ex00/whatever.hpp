/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   whatever.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 14:51    by ekocak            #+#    #+#             */
/*   Updated: 2023/08/17 14:51    by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WHATEVER_HPP
# define WHATEVER_HPP

#include <string>


/* 
 * swap: Swaps the values of two given arguments. 
 * Does not return anything.
 *
 * I have declared T as the placeholder of the data type
 */
template <typename T>
void swap(T &parA, T &parB)
{
    T   temp;

    temp = parA;
    parA = parB;
    parB = temp;
}

/*
 * min: Compares the two values passed in its arguments 
 * and returns the smallest one. If the two of them are 
 * equal, then it returns the second one.
 */

template <typename T>
T   &min(T &parA, T &parB)
{
    return (parA < parB ? parA : parB);
}

/*
 * max: Compares the two values passed in its arguments 
 * and returns the greatest one. If the two of them are 
 * equal, then it returns the second one.
 */

template <typename T>
T  &max(T &parA, T &parB)
{
return (parA > parB ? parA : parB);
}

#endif