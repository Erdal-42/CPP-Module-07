/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/17 14:51    by ekocak            #+#    #+#             */
/*   Updated: 2023/08/17 14:51    by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "whatever.hpp"
#include <iostream>
/*
int main()
{
    char a = 'm';
    char b = 'd';

    std::cout << "MIN: " << min(a, b) << std::endl;   
    std::cout << "MAX: " << max(a, b) << std::endl;
    std::cout << "Parameter 1: " << a << "\tParameter 2: " << b << std::endl;
    swap(a, b);
    std::cout << "SWAP.. \n" << "Parameter 1: " << a << "\tParameter 2: " << b << std::endl;
    return (0);
} */
int main( void ) 
{
    int a = 2;
    int b = 3;
    ::swap( a, b );
    std::cout << "a = " << a << ", b = " << b << std::endl;
    std::cout << "min( a, b ) = " << ::min( a, b ) << std::endl;
    std::cout << "max( a, b ) = " << ::max( a, b ) << std::endl;
    std::string c = "chaine1";
    std::string d = "chaine2";
    ::swap(c, d);
    std::cout << "c = " << c << ", d = " << d << std::endl;
    std::cout << "min( c, d ) = " << ::min( c, d ) << std::endl;
    std::cout << "max( c, d ) = " << ::max( c, d ) << std::endl;
    return 0;
}