/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/19 02:41    by ekocak            #+#    #+#             */
/*   Updated: 2023/08/19 02:41    by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "iter.hpp"
#include <string>

template <typename T>
void    advance(T& param)
{
    param += 1;
}

template <typename T>
void    retreat(T& param)
{
    param -= 1;
}

template <typename T>
void    printArray(T *array, int size)
{
    std::cout << "{";
    for (int i = 0; i < size; i ++)
    {
        std::cout << array[i];
        if (i != size - 1)
            std::cout << ", ";
    }
    std::cout << "}";
}

int main()
{
    int size = 3;
    std::cout << "=======TESTING THE ITER FUNCTION=======" << std::endl;
    int arrayInt[size] = {1, 2, 3};
    printArray(arrayInt, size);       
    std::cout << "\tFunction: advance\n";
    iter(arrayInt, size, &advance);
    printArray(arrayInt, size);
    std::cout << std::endl << std::endl;

    double arrayDouble[size] = {0.5, 1.5, 2.5};
    printArray(arrayDouble, size); 
    std::cout << "\tFunction: advance\n";
    iter(arrayDouble, size, &advance);
    printArray(arrayDouble, size);
    std::cout << std::endl << std::endl;

    char arrayChar[3] = {'a', 'b', 'c'};
    printArray(arrayChar, size);
    std::cout << "\tFunction: advance\n";
    iter(arrayChar, 3, &advance);
    printArray(arrayChar, size);
    std::cout << std::endl << std::endl;

    printArray(arrayInt, size);
    std::cout << "\tFunction: retreat\n";
    iter(arrayInt, 3, &retreat);
    printArray(arrayInt, size);
    std::cout << std::endl << std::endl;

    printArray(arrayDouble, size);
    std::cout << "\tFunction: retreat\n";
    iter(arrayDouble, size, &retreat);
    printArray(arrayDouble, size);
    std::cout << std::endl << std::endl;

    printArray(arrayChar, size);
    std::cout << "\tFunction: retreat\n";
    iter(arrayChar, size, &retreat);
    printArray(arrayChar, size);
    std::cout << std::endl;

    return (0);
}
