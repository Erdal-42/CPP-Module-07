/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   iter.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/19 02:41    by ekocak            #+#    #+#             */
/*   Updated: 2023/08/19 02:41    by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ITER_HPP
# define ITER_HPP

#include <iostream>
#include <string>

template <typename T>
void    advance(T&);
template <typename T>
void    retreat(T&);

template <typename T>
void    iter(T *array, int size, void (*function)(T&))
{
    for (int i = 0; i < size; i ++)
    {
        function(array[i]);
    }
}


#endif
