/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Array.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/22 18:08    by ekocak            #+#    #+#             */
/*   Updated: 2023/08/22 18:08    by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <ostream>
#include <string>

#define DEBUG 1

template <typename T>

class Array
{
    private:
        T       *_data;
        unsigned _size;
    public:
        Array(): _data(NULL), _size(0)
        {
#if DEBUG
            std::cout << "Default constructor has constructed an instance of class Array." << std::endl; 
#endif
        }

        Array<T>(unsigned n)
        {
            _data = new T[n];
            _size = n;
#if DEBUG
            std::cout << "Parametized constructor has constructed an instance of class Array." << std::endl; 
#endif
        }
        Array(const Array& other)
        {
            this->_data = new T[other._size];
            for (unsigned i = 0; i < other._size; i ++)
                _data[i] = other._data[i];
            this->_size = other._size;
#if DEBUG
            std::cout << "Copy constructed an instance of class Array\t" << *this << std::endl; 
#endif
        }

        Array& operator=(const Array &other)
        {
            if (this != &other)
            {
                delete [] _data;
                this->_data = new T[other._size];
                for (unsigned i = 0; i < other._size; i ++)
                    _data[i] = other._data[i];
                this->_size = other._size;
            }
#if DEBUG
            std::cout << "Assigned Array\t" << *this << std::endl; 
#endif
            return (*this);
        }

        ~Array() 
        {
#if DEBUG
            std::cout << "Deleting Array\t" << *this << std::endl; 
#endif
            delete [] _data;
        };

        T& operator[](unsigned index)
        {
            if (index < 0 || index >= _size)
                throw (OutOfBoundsException());
            return (_data[index]);
        }

        T *getArray() const
        {
            return  (_data);
        }

        void setArray(T *theData, unsigned theSize)
        {    
            delete _data;
            _data = new T[_size];
            for (unsigned i = 0; i < _size && i < theSize; i ++)
            {
                _data[i] = theData[i];
            }
        }

        unsigned size() const
        {
            return (_size);
        }

        class OutOfBoundsException : public std::exception
        {
            public:
                virtual const char *what() const throw()
                {
                    return ("Index is out of bounds.");
                }
        };
};

template <typename T>
std::ostream &	operator<<(std::ostream &os, Array<T> &obj) 
{
    os << "{";
    for (unsigned int i = 0; i < obj.size(); ++i) {
        os << obj[i];
        if (i != obj.size() - 1)
            os << ", ";    
    }
    os << "}";
    return (os);
}
